//Variables globales
var http = new XMLHttpRequest();
var tbody;
var id;
//Fin de variables globales

window.addEventListener("load",Listar)
window.addEventListener("load",Inicializar)


function Listar()
{
    http.open("GET","http://localhost:3000/materias",true);
    http.onreadystatechange = Recibir;
    http.send();
}

function Inicializar()
{
    var btnEliminar = $("btnEliminar");
    var btnModificar = $("btnModificar");
    var btnCerrar = $("btnClose");
    btnEliminar.addEventListener("click",Borrar);
    btnModificar.addEventListener("click",Modificar);
    btnCerrar.addEventListener("click",Cerrar);
 
}

function Recibir()
{
    if(Equals(http.readyState,4) && Equals(http.status,200))
    {
        var materias = JSON.parse(http.responseText);
        var bodyHTML = $("body");
        var h2 = CreateElement("h2");
        h2.appendChild(CreateTextNode("Lista de Personas"));
        SetAttibutes(h2,"class","negrita");
        bodyHTML.appendChild(h2);
        bodyHTML.appendChild(CrearTabla());
        tbody = bodyHTML.lastChild.lastChild;
        CargarGrilla(materias);
    }  
}

function CrearTabla()
{
    var tbl = CreateElement("table");
    SetAttibutes(tbl,"border","0");
    SetAttibutes(tbl,"id","table");
    SetAttibutes(tbl,"class","tabla");
    tbl.appendChild(CrearCabeceraTabla());
    tbl.appendChild(CrearCuerpoTabla());
    return tbl;  
}

function CrearCabeceraTabla()
{
    //Spinner(1);
    var thead = CreateElement("thead");
    var tr = CreateElement("tr");
    var th1 = CreateElement("td");
    th1.appendChild(CreateTextNode("Id"));
    var th2 = CreateElement("td");
    th2.appendChild(CreateTextNode("Materia"));
    var th3 = CreateElement("td");
    th3.appendChild(CreateTextNode("Cuatrimestre"));
    var th4 = CreateElement("td");
    th4.appendChild(CreateTextNode("FechaFinal"));
    var th5 = CreateElement("td");
    th5.appendChild(CreateTextNode("Turno"));
    tr.appendChild(th1);
    tr.appendChild(th2);
    tr.appendChild(th3);
    tr.appendChild(th4);
    tr.appendChild(th5);
    SetAttibutes(tr,"class","tr");
    return tr;
}

function Abrir(event) //Tiene que recibir un evento
{
    event.preventDefault();
    var trClick = event.target.parentNode;
    document.getElementById("id").value = trClick.childNodes[0].innerHTML;
    document.getElementById("materia").value = trClick.childNodes[1].innerHTML;
    document.getElementById("cuatrimestre").value = trClick.childNodes[2].innerHTML;
    document.getElementById("fechaFinal").value = trClick.childNodes[3].innerHTML;

    if(trClick.childNodes[4].innerHTML == "Mañana")
    {
        document.getElementById("rdMañana").checked = true;
    }
    if(trClick.childNodes[4].innerHTML == "Noche")
    {
        document.getElementById("rdNoche").checked = true;
    }

    $("contAgregar").hidden = false;
}

function CrearCuerpoTabla()
{
    //Spinner(1);
    var tbody = CreateElement("tbody");
    SetAttibutes(tbody,"id","tbody");
    //SetAttibutes($("imgLoading"),"class","imgLoadingVisible");
    return tbody;
}

function CreateElement(type)
{
    var element = document.createElement(type);
    return element;
}

function CreateTextNode(str)
{
    return document.createTextNode(str);
}

function BoShowMessage(str)
{
    alert(str);
}

function $(id)
{
    return document.getElementById(id);
}

function Equals(val1, val2)
{
    return val1 === val2;
}

function SetAttibutes(obj, field, value)
{
    obj.setAttribute(field, value);
}

function CargarGrilla(entidades)
{
    CrearTabla();

    for(var i = 0; i < entidades.length; i++)
    {
        var row = CreateElement("tr");
        var aBO = entidades[i];
        var columns = Object.keys(aBO);

        for(var j = 0; j < columns.length + 1; j++)
        {
            var cel = CreateElement("td");
            if(j < 5)
            {
                cel.appendChild(CreateTextNode(aBO[columns[j]]));
            }
            
            row.appendChild(cel);
        }
        tbody.appendChild(row);
        tbody.addEventListener("dblclick", Abrir);
    }
}

function Modificar()
{
    var id = $("id");
    var materia = $("materia");
    var cuatrimestre = $("cuatrimestre");
    var fecha = $("fechaFinal");
    var turno;

    if(Equals(materia.value,"") || materia.value.length < 6)
    {
        BoShowMessage("Debe ingresar una materia!!");
        SetAttibutes(materia,"class","Error");
        return;
    }

    if(Equals(fecha.value,"") || fecha.value < fecha.min)
    {
        BoShowMessage("Debe ingresar la fecha!!");
        SetAttibutes(fecha,"class","Error");
        return;
    }

    if($("rdMañana").checked == true)
    {
        turno = $("rdMañana");
    }
    if($("rdNoche").checked == true)
    {
        turno = $("rdNoche");
    }


    if(confirm("Esta seguro que desea modificar esta materia a la lista??"))
    {
        http.open("POST","http://localhost:3000/editar",true);// id para eliminar + datos para guardar
        http.setRequestHeader("Content-type", "application/json");
        http.onreadystatechange = RecibirPOST;

        http.send(JSON.stringify(FormatJson(id, materia, cuatrimestre, fecha, turno)));
        
        
        $("contAgregar").hidden = true;    
    }
    else
    {
        Abrir;
    }

    SetAttibutes($("imgLoading"),"class","imgLoadingVisible");
}

function RecibirPOST()
{
    Spinner(1);

    if(Equals(http.readyState,4) && Equals(http.status,200))
    {
       var row = CreateElement("tr");
       var celId = CreateElement("td");
       celId.appendChild(CreateTextNode($("id").value));
       var celMat = CreateElement("td");
       celMat.appendChild(CreateTextNode($("materia").value));
       var celCua = CreateElement("td");
       celCua.appendChild(CreateTextNode($("cuatrimestre").value));
       var celF = CreateElement("td");
       celF.appendChild(CreateTextNode($("fechaFinal").value));
       var celTurno = CreateElement("td");

       if($("rdMañana").checked == true)
       {
          celTurno.appendChild(CreateTextNode($("rdMañana").value));
       }
       else if($("rdNoche").checked == true)
       {
          celTurno.appendChild(CreateTextNode($("rdNoche").value));
       }

       row.appendChild(celId);
       row.appendChild(celMat);
       row.appendChild(celCua);
       row.appendChild(celF);
       row.appendChild(celTurno);
       
       SetAttibutes($("imgLoading"),"class","imgLoadingInvisible");
       tbody.appendChild(row);
       Spinner(2);
       location.reload();
    }
}

function FormatJson(id, mat, cua, fecha, turno)
{
    return {id: id.value, nombre : mat.value, cuatrimestre : cua.value, fechaFinal : fecha.value, turno: turno.value};
}

function Borrar()
{
    Spinner(1);
    http.onreadystatechange=function(){
        if(http.readyState==4 && http.status==200)
        {
            location.reload();
            document.getElementById("contAgregar").hidden=true;
        }
    }

    http.open("POST","http://localhost:3000/eliminar", true);
    http.setRequestHeader("Content-Type","application/json");
    SetAttibutes($("imgLoading"),"class","imgLoadingVisible");
    var json = {id:document.getElementById("id").value}

    http.send(JSON.stringify(json));
}

function fecha(){

    let data= new Date();

   /* alert(document.getElementById("fecha").value);*/
    var fecha= "2000-01-01";
    var fechaEnArray = fecha.split("-");//Divide un string en un array delimitado por -
    //osea nos da un array de 3 donde en el index 0 esta el año, 1 el mes y 2 el dia
    data.setFullYear(fechaEnArray[0]);
    //Los meses para un date arrancan de 0. Si los tenemos que setear -1 y cuando los mostramos +1
    data.setMonth(fechaEnArray[1]-1);
    data.setDate(fechaEnArray[2]);

    alert("Dia del nacimiento "+data.getDate());
    alert("Mes del nacimiento "+data.getMonth()+1);
    alert("Año del nacimiento "+ data.getFullYear());

    //Cuando generamos un date, siempre toma la fecha del navegador.
    var fechaHoy = new Date();
    alert("Hoy es"+fechaHoy.getDate()+ " del mes "+
    (fechaHoy.getMonth()+1)+" del del año "+fechaHoy.getFullYear());
}

function Cerrar()
{
    var contenedor = $("contAgregar");
    contenedor.hidden = true;
}

function Spinner(key)
{
    switch (key) {
        case '1':
            document.getElementById("loading").removeAttribute("hidden");
        break;
    
        case '2':
            document.getElementById("loading").setAttribute("hidden",true);
        break;
    }
}






